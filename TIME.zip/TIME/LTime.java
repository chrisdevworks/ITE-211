import java.util.Scanner;

public class LTime {
	
	public int hours;
	public int minutes;
	public int seconds;

    public void Time(int x) {
    	hours = x/3600;
    	x = x % 3600;
    	minutes = x/60;
    	x = x % 60;
		seconds = x;

    	System.out.printf("%d : %d : %d", hours, minutes, seconds);
    }
    
    
}